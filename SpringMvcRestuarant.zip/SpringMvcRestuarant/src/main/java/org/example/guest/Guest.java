package org.example.guest;

import java.time.LocalDateTime;

public record Guest(String name, LocalDateTime time) {
}
